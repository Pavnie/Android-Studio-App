# MyCurrentLocation
 Hello Everyone, In this tutorial we will learn how to get current location in android device using Location Manager calss

Watch Tutorial on -
[Youtube](https://youtu.be/qY-xFxZ7HKY)

![GitHub Logo](/current_location.jpg)
 
